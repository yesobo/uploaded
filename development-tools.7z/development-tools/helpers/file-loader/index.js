const fs = require('fs');
const path = require('path');
const process = require('process');

function getFileDir (name, type) {
  let localFile = `./${name}`;
  let existsLocalFile = fs.existsSync(path.resolve(process.cwd(), localFile));
  let dirName = path.parse(name).dir;
  let fileName = path.parse(name).base;
  let toolsFile = `./${path.relative(process.cwd(), path.resolve(
    __dirname,
    '..',
    '..',
    dirName,
    type || '',
    fileName
  ))}`;

  return existsLocalFile ? localFile : toolsFile;
}

module.exports = getFileDir;
