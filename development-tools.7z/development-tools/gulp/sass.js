const gulp = require('gulp');
const config = require('./config');
const helperSass = require('./helpers/sass.js');

function sass() {
    return helperSass(config.paths.temp, config.paths.temp);
}
sass.description = "Compiles scss to css.";

module.exports = sass;
