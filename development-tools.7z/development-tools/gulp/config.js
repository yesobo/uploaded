var path = require('path');
var defaultConfig = path.resolve(__dirname, '../config/library/tsconfig.json');
var customConfig = path.resolve(process.cwd(), 'tsconfig.tools.json');
var fs = require('fs');

exports.paths = {
  src: 'src',
  dist: 'dist',
  temp: '.tmp'
};

exports.tsconfig = fs.existsSync(customConfig) ? customConfig : defaultConfig;