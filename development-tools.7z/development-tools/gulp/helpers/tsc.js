const gulp = require('gulp');
const typescript = require('gulp-typescript');
const merge = require('merge2');
const sourcemaps = require('gulp-sourcemaps');

module.exports = function (sourceDirs, destDir, tsconfig) {
  let tsProject = typescript.createProject(tsconfig, {
      declaration: true
    });
  let tsResult = gulp
    .src(sourceDirs)
    .pipe(sourcemaps.init())
    .pipe(tsProject());

  return merge([
    tsResult.dts
      .pipe(gulp.dest(destDir)),
    tsResult.js
    .pipe(sourcemaps.write('.'))
    .pipe(gulp.dest(destDir))
  ]);
}