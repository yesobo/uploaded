const gulp = require('gulp');
const helperCopy = require('./helpers/copy');
const config = require('./config');

function copy() {
    return helperCopy(config.paths.src, config.paths.temp);
}
copy.description = "Copy src files to tmp directory.";

module.exports = copy;
