const gulp = require('gulp');
const helperInlineResources = require('./helpers/inline-resources');
const config = require('./config');

function inlineResources(done) {
    return helperInlineResources(config.paths.temp, done);
}
inlineResources.description = "Replaces styles and template reference for inline resources.";

module.exports = inlineResources;
