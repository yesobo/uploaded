const util = require('util');
const DefaultRegistry = require('undertaker-registry');
const cleanTask = require('./clean');
const copyTask = require('./copy');
const pugTask = require('./pug');
const sassTask = require('./sass');
const inlineResources = require('./inline-resources');
const tscTask = require('./tsc');
const indexTask = require('./index');
const distTask = require('./dist');

function BankularTaskRegistry() {
  DefaultRegistry.call(this);
}
util.inherits(BankularTaskRegistry, DefaultRegistry);

BankularTaskRegistry.prototype.init = function(gulp) {
  gulp.task('clean:dist', cleanTask.cleanDist);
  gulp.task('clean:tmp', cleanTask.cleanTmp);
  gulp.task('clean:index', cleanTask.cleanIndex);
  gulp.task('copy', copyTask);
  gulp.task('pug', pugTask);
  gulp.task('sass', sassTask);
  gulp.task('inline-resources', (done) => inlineResources(done));
  gulp.task('tsc', tscTask);
  gulp.task('index', (callback) => indexTask(callback));
  gulp.task('dist', distTask());
};

module.exports = new BankularTaskRegistry();
