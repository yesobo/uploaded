const gulp = require('gulp');
const config = require('./config');
const helperTsc = require('./helpers/tsc');
const sourceDirs = [
  `${config.paths.temp}/**/*.ts`,
  `!${config.paths.temp}/**/*.{spec,e2e}.ts`
];

function tsc() {
  return helperTsc(sourceDirs, config.paths.dist, config.tsconfig);
}
tsc.description = "Compiles tsc files in plain javascript.";

module.exports = tsc;