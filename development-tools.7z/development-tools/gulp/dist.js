const gulp = require('gulp');

function dist() {
  return gulp.series('clean:dist',
    'clean:tmp',
    'clean:index',
    'copy',
    gulp.parallel('pug', 'sass'),
    'inline-resources',
    'tsc',
    'index'
  );
}
dist.description = "Task for generate a distribution";
module.exports = dist;
