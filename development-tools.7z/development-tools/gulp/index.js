const gulp = require('gulp');
const config = require('./config');
const helperIndex = require('./helpers/index');

function index(callback) {
    return helperIndex(config.paths.dist, callback);
}
index.description = "Creates index.js and index.d.ts.";

module.exports = index;
