const gulp = require('gulp');
const helperPug = require('./helpers/pug');
const config = require('./config');

function pug() {
    return helperPug(config.paths.temp, config.paths.temp);
}
pug.description ='Compiles pug files in HTML files.';

module.exports = pug;
