const gulp = require('gulp');
const helperDel = require('./helpers/clean');

function cleanDist(done) {
  return helperDel('dist', done);
}
cleanDist.description = "Clean dist directory.";

function cleanTmp(done) {
  return helperDel('.tmp', done);
}
cleanTmp.description = "Clean tmp directory.";

function cleanIndex(done) {
  return helperDel(['index.js', 'index.d.ts'], done);
}
cleanIndex.description = "Remove index.js and index.d.ts files";

module.exports = {
  cleanDist: cleanDist,
  cleanTmp: cleanTmp,
  cleanIndex: cleanIndex
};
