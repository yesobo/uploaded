const helpers = require('./helpers');
const webpack = require('webpack');
const path = require('path');

module.exports = {
  devtool: 'inline-source-map',

  resolve: {
    extensions: ['.ts', '.js']
  },

  plugins: [
    new webpack.ContextReplacementPlugin(
      // The (\\|\/) piece accounts for path separators in *nix and Windows
      /angular(\\|\/)core(\\|\/)src(\\|\/)linker/,
      path.resolve(process.cwd(), './src'),
      {
        // your Angular Async Route paths relative to this root directory
      }
    )
  ],

  module: {
    loaders: [
     {
        test: /\.ts$/,
        exclude: /(node_modules)/,
        loaders: ['awesome-typescript-loader', 'angular2-template-loader']
      },
      {
        test: /\.html$/,
        loader: 'html-loader'
      },
      {
        test:  /\.pug$/,
        exclude: /node_modules/,
        loader: 'pug-html-loader'
      },
      {
        test: /\.css$/,
        exclude: /node_modules/,
        loaders: ['to-string-loader', 'css-loader', 'postcss-loader']
      },
      {
        test: /\.scss$/,
        exclude: /node_modules/,
        loaders: ['to-string-loader', 'css-loader', 'postcss-loader', 'sass-loader']
      },
      {
        test: /\.css$/,
        exclude: /src/,
        loader: 'style-loader!css-loader'
      },
    ]
  }
}
