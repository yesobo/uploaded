const webpackConfig = require('./webpack.test');
const process = require('process');
const path = require('path');
const shimFile = `${path.resolve(process.cwd(), __dirname)}/karma-test-shim.js`;

module.exports = function (config) {
  let _config = {
    basePath: '',

    frameworks: ['jasmine'],

    files: [
      {pattern: `${shimFile}`, watched: false}
    ],

    preprocessors: {},

    webpack: webpackConfig,

    webpackMiddleware: {
      stats: 'errors-only'
    },

    webpackServer: {
      noInfo: true
    },

    reporters: ['mocha'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: false,
    browsers: ['PhantomJS'],
    singleRun: true
  };

  config.preprocessors[shimFile] = ['webpack', 'sourcemap'];

  config.set(_config);
};
