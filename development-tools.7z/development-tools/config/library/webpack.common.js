const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const LoaderOptionsPlugin = require("webpack/lib/LoaderOptionsPlugin");
const helpers = require('../helpers');
const process = require('process');
const path = require('path');
let defaultConfig = path.resolve(__dirname, 'tsconfig.json');
let customConfig = path.resolve(process.cwd(), 'tsconfig.tools.json');
const fs = require('fs');

module.exports = {
  entry: {
    'polyfills':'./demo/polyfills.ts',
    'vendor': './demo/vendor.ts',
    'app': './demo/main.ts'
  },

  resolve: {
    extensions: ['.js', '.ts'],
    modules: [ path.resolve(process.cwd(), 'node_modules') ]
  },

  output: {
    filename: '[id].[hash].[bundle].js'
  },

  module: {
    rules: [
      {
        enforce: 'pre',
        test: /\.ts$/,
        loader: 'tslint-loader',
        exclude: /(node_modules)/,
      },
      {
        test: /\.ts$/,
        exclude: /(node_modules)/,
        loader: 'awesome-typescript-loader',
        query: {
          tsconfig: fs.existsSync(customConfig) ? customConfig : defaultConfig
        }
      },
      {
        test: /\.ts$/,
        exclude: /(node_modules)/,
        loader: 'angular2-template-loader'
      },
      {
        test: /\.html$/,
        loader: 'html-loader'
      },
      {
        test:  /\.pug$/,
        exclude: /node_modules/,
        loader: 'pug-html-loader'
      },
      {
        test: /\.css$/,
        exclude: /node_modules/,
        loaders: ['to-string-loader', 'css-loader', 'postcss-loader']
      },
      {
        test: /\.scss$/,
        exclude: /node_modules/,
        loaders: ['to-string-loader', 'css-loader', 'postcss-loader', 'sass-loader']
      },
      {
        test: /\.css$/,
        exclude: /src/,
        loader: 'style-loader!css-loader'
      },
			{
        test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
        loader: "file-loader"
      },
			{
        test: /\.(woff|woff2)$/,
        loader:"url-loader?prefix=font/&limit=5000"
      },
			{
        test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
        loader: "url-loader?limit=10000&mimetype=application/octet-stream"
      },
			{
        test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
        loader: "url-loader?limit=10000&mimetype=image/svg+xml"
      }
    ]
  },

  plugins: [
    new webpack.optimize.CommonsChunkPlugin({
      name: ['app', 'vendor', 'polyfills']
    }),

    new HtmlWebpackPlugin({
      template: 'demo/index.html'
    }),

    new webpack.ContextReplacementPlugin(
      /angular(\\|\/)core(\\|\/)(esm(\\|\/)src|src)(\\|\/)linker/,
      process.cwd()
    ),

    new LoaderOptionsPlugin({
      options: {
        tslint: {
          emitErrors: false,
          formatter: "stylish",
          formattersDirectory: "node_modules/tslint-stylish"
        }
      }
    })
  ]
};