const loader = require('@bankular/development-tools/helpers/file-loader');

module.exports = require(loader('config/karma.conf.js'));
