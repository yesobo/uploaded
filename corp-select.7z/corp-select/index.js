exports.BkCorpSelectOptionComponent = require('./dist/select-option.component.js').BkCorpSelectOptionComponent;
exports.BkCorpSelectComponent = require('./dist/select.component.js').BkCorpSelectComponent;
exports.BkCorpSelectModule = require('./dist/select.module.js').BkCorpSelectModule;