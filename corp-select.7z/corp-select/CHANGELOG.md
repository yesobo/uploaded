<a name="0.1.1"></a>
## [0.1.1](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/compare/v0.1.0...v0.1.1) (2016-11-30)


### Features

* Included auto recomme ([6466397](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/6466397))



<a name="0.1.0"></a>
# [0.1.0](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/compare/3faaf6d...v0.1.0) (2016-11-30)


### Bug Fixes

* **config:** nueva configuracion. ([7a22f8b](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/7a22f8b))
* **dist:** corregido index. ([a04fadc](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/a04fadc))
* **styles:** Estilos en linea ([44f6be6](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/44f6be6))
* **styles-rev:** add ux styles revision &  core styles ([8dc6198](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/8dc6198))
* **webpack:** actualizacion config ([eb4cbae](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/eb4cbae))
* **webpack:** fix dist ([e050d35](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/e050d35))


### Features

* **BkCorpSelect:** primera implementación ([3faaf6d](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/3faaf6d))
* **readme:** añadimos primera vesión de la documentación del componente. ([a3f2584](https://aqdes-stash.cm.es/stash/scm/arqteaqac/corp-select/commits/a3f2584))



